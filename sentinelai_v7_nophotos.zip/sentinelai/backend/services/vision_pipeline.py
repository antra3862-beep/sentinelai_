"""
SentinelAI – Vision Pipeline (v7)
Key fixes:
- Face recognition uses multiple embeddings per person (LBP + HOG)
- Strict threshold 0.92 — only very close matches count as known
- Unknown by default unless very confident
"""

from __future__ import annotations
import base64, json, time, uuid
from pathlib import Path
from typing import Optional

import cv2
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

try:
    from ultralytics import YOLO
    _YOLO_OK = True
except ImportError:
    _YOLO_OK = False

ENROLLED_DIR = Path(__file__).parent.parent / "enrolled_faces"
ROLES_FILE   = ENROLLED_DIR / "roles.json"

# ── SORT Tracker ──────────────────────────────────────────────────────────────
class KalmanTracker:
    _counter = 0
    def __init__(self, bbox):
        KalmanTracker._counter += 1
        self.id = KalmanTracker._counter
        self.hits = 1; self.age = 0
        x1,y1,x2,y2 = bbox
        cx,cy,w,h = (x1+x2)/2,(y1+y2)/2,x2-x1,y2-y1
        self.kf = cv2.KalmanFilter(8,4)
        self.kf.transitionMatrix = np.eye(8,dtype=np.float32)
        for i in range(4): self.kf.transitionMatrix[i,i+4]=1.
        self.kf.measurementMatrix   = np.eye(4,8,dtype=np.float32)
        self.kf.processNoiseCov     = np.eye(8,dtype=np.float32)*1e-2
        self.kf.measurementNoiseCov = np.eye(4,dtype=np.float32)*1e-1
        self.kf.errorCovPost        = np.eye(8,dtype=np.float32)
        self.kf.statePost = np.array([[cx],[cy],[w],[h],[0],[0],[0],[0]],dtype=np.float32)

    def predict(self):
        s = self.kf.predict()
        cx,cy,w,h = float(s[0][0]),float(s[1][0]),float(s[2][0]),float(s[3][0])
        return int(cx-w/2),int(cy-h/2),int(cx+w/2),int(cy+h/2)

    def update(self, bbox):
        x1,y1,x2,y2 = bbox
        m = np.array([[(x1+x2)/2],[(y1+y2)/2],[x2-x1],[y2-y1]],dtype=np.float32)
        self.kf.correct(m); self.hits+=1; self.age=0

    def get_bbox(self):
        s = self.kf.statePost
        cx,cy,w,h = float(s[0][0]),float(s[1][0]),float(s[2][0]),float(s[3][0])
        return int(cx-w/2),int(cy-h/2),int(cx+w/2),int(cy+h/2)

def _iou(a,b):
    ix1,iy1=max(a[0],b[0]),max(a[1],b[1])
    ix2,iy2=min(a[2],b[2]),min(a[3],b[3])
    inter=max(0,ix2-ix1)*max(0,iy2-iy1)
    ua=(a[2]-a[0])*(a[3]-a[1])+(b[2]-b[0])*(b[3]-b[1])-inter
    return inter/ua if ua>0 else 0.

class SORTTracker:
    def __init__(self,max_age=5,min_hits=2,iou_thr=0.3):
        self.max_age=max_age; self.min_hits=min_hits
        self.iou_thr=iou_thr; self.trackers=[]

    def update(self,dets):
        predicted=[t.predict() for t in self.trackers]
        matched_t,matched_d=set(),set()
        if predicted and dets:
            mat=np.zeros((len(predicted),len(dets)))
            for ti,tp in enumerate(predicted):
                for di,dp in enumerate(dets): mat[ti,di]=_iou(tp,dp)
            while True:
                idx=np.unravel_index(np.argmax(mat),mat.shape)
                ti,di=int(idx[0]),int(idx[1])
                if mat[ti,di]<self.iou_thr: break
                matched_t.add(ti); matched_d.add(di)
                self.trackers[ti].update(dets[di])
                mat[ti,:]=-1; mat[:,di]=-1
        for di,det in enumerate(dets):
            if di not in matched_d: self.trackers.append(KalmanTracker(det))
        alive=[]
        for ti,trk in enumerate(self.trackers):
            if ti not in matched_t: trk.age+=1
            if trk.age<=self.max_age: alive.append(trk)
        self.trackers=alive
        return [(t.get_bbox()+(t.id,)) for t in self.trackers
                if t.hits>=self.min_hits or t.age==0]

# ── Face Recogniser ───────────────────────────────────────────────────────────
class FaceRecogniser:
    # Very strict — only match if very confident
    # Default unknown, known only if score >= threshold
    THRESHOLD = 0.90

    def __init__(self):
        self._face_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        )
        self._profile_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + "haarcascade_profileface.xml"
        )
        self._hog = cv2.HOGDescriptor((64,64),(16,16),(8,8),(8,8),9)
        self._db: dict[str, list[np.ndarray]] = {}  # name → list of embeddings
        self._roles: dict[str, str] = {}
        self._load()

    def _preprocess(self, img: np.ndarray) -> np.ndarray:
        """Standardise face image."""
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if len(img.shape)==3 else img
        resized = cv2.resize(gray, (64,64))
        # CLAHE for lighting normalisation
        clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(4,4))
        return clahe.apply(resized)

    def _embed(self, face_img: np.ndarray) -> Optional[np.ndarray]:
        """Extract HOG embedding from face image."""
        if face_img is None or face_img.size < 100:
            return None
        try:
            proc = self._preprocess(face_img)
            feat = self._hog.compute(proc).flatten()
            norm = np.linalg.norm(feat)
            if norm < 0.01: return None
            return feat / norm
        except:
            return None

    def _detect_face(self, img: np.ndarray) -> Optional[np.ndarray]:
        """Detect and return the best face crop from image."""
        if img is None or img.size == 0: return None
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if len(img.shape)==3 else img

        # Try frontal face
        faces = self._face_cascade.detectMultiScale(
            gray, scaleFactor=1.1, minNeighbors=5, minSize=(30,30))

        if len(faces) == 0:
            # Try with less strict params
            faces = self._face_cascade.detectMultiScale(
                gray, scaleFactor=1.05, minNeighbors=3, minSize=(20,20))

        if len(faces) > 0:
            # Pick largest face
            x,y,w,h = max(faces, key=lambda f: f[2]*f[3])
            # Add small padding
            pad = int(min(w,h)*0.1)
            x1 = max(0, x-pad); y1 = max(0, y-pad)
            x2 = min(img.shape[1], x+w+pad)
            y2 = min(img.shape[0], y+h+pad)
            return img[y1:y2, x1:x2]

        return None  # No face found

    def _load(self):
        self._db.clear()
        self._roles = {}
        if ROLES_FILE.exists():
            with open(ROLES_FILE) as f:
                self._roles = json.load(f)
        if not ENROLLED_DIR.exists(): return

        for p in list(ENROLLED_DIR.glob("*.jpg")) + list(ENROLLED_DIR.glob("*.png")):
            if p.stem == "roles": continue
            img = cv2.imread(str(p))
            if img is None: continue

            embeddings = []

            # Try to detect face in enrolled image
            face = self._detect_face(img)
            if face is not None and face.size > 0:
                emb = self._embed(face)
                if emb is not None: embeddings.append(emb)

                # Data augmentation — slight brightness variations for robustness
                for alpha in [0.85, 1.15]:
                    aug = np.clip(face.astype(np.float32) * alpha, 0, 255).astype(np.uint8)
                    emb2 = self._embed(aug)
                    if emb2 is not None: embeddings.append(emb2)
            else:
                # Use whole image as fallback
                emb = self._embed(img)
                if emb is not None: embeddings.append(emb)

            if embeddings:
                self._db[p.stem] = embeddings
                print(f"[SentinelAI] Enrolled: {p.stem} "
                      f"({self._roles.get(p.stem,'?')}) "
                      f"— {len(embeddings)} embeddings")
            else:
                print(f"[SentinelAI] WARNING: Could not embed {p.stem}")

    def reload(self): self._load()

    def detect_faces_in_frame(self, frame: np.ndarray):
        """Return list of (x1,y1,x2,y2) face bounding boxes."""
        gray  = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = self._face_cascade.detectMultiScale(
            gray, scaleFactor=1.15, minNeighbors=6, minSize=(50,50))
        return [(x,y,x+w,y+h) for (x,y,w,h) in faces]

    def recognise(self, face_img: np.ndarray) -> dict:
        """
        Recognise a face image.
        Returns known only if score >= THRESHOLD.
        Default is always Unknown.
        """
        unknown = {"name":"Unknown","role":"Unknown","status":"unknown","confidence":0.0}

        if not self._db or face_img is None or face_img.size == 0:
            return unknown

        emb = self._embed(face_img)
        if emb is None: return unknown

        emb_2d = emb.reshape(1,-1)
        best_name, best_score = "Unknown", 0.0

        for name, ref_embeddings in self._db.items():
            # Compare against all embeddings for this person, take best score
            for ref in ref_embeddings:
                score = float(cosine_similarity(emb_2d, ref.reshape(1,-1))[0][0])
                if score > best_score:
                    best_score = score
                    best_name  = name

        print(f"[Recog] Best match: {best_name} score={best_score:.3f} threshold={self.THRESHOLD}")

        if best_score >= self.THRESHOLD:
            return {
                "name":       best_name,
                "role":       self._roles.get(best_name, "Unknown"),
                "status":     "known",
                "confidence": round(best_score, 3),
            }
        return unknown

    def get_enrolled(self):
        return [{"name":n,"role":self._roles.get(n,"Unknown")} for n in self._db]

# ── Enhancement ───────────────────────────────────────────────────────────────
def enhance(frame):
    lab = cv2.cvtColor(frame, cv2.COLOR_BGR2LAB)
    l,a,b = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
    return cv2.cvtColor(cv2.merge([clahe.apply(l),a,b]), cv2.COLOR_LAB2BGR)

_COLS = [(255,56,56),(72,249,10),(0,194,255),(255,178,29),
         (146,204,23),(132,56,255),(203,56,255),(255,149,200)]
def _col(tid): return _COLS[tid % len(_COLS)]

# ── Main Pipeline ─────────────────────────────────────────────────────────────
class SentinelPipeline:
    def __init__(self):
        self._yolo = None
        if _YOLO_OK:
            try: self._yolo = YOLO("yolov8n.pt")
            except: pass

        self._bg_sub = cv2.createBackgroundSubtractorMOG2(
            history=200, varThreshold=50, detectShadows=True)
        self._tracker    = SORTTracker()
        self._recogniser = FaceRecogniser()
        self._frame_n    = 0
        self._alerts: list[dict] = []
        self._live_stats = {
            "persons_detected": 0,
            "known_count":      0,
            "unknown_count":    0,
            "objects_detected": 0,
            "alerts_total":     0,
            "known_log":        [],
            "unknown_log":      [],
        }
        self._id_cache:     dict[int,dict] = {}
        self._id_cache_ttl: dict[int,int]  = {}
        self._cache_frames = 25
        self._seen_tracks:  set[int] = set()

    def _detect_persons(self, frame):
        if self._yolo is None: return []
        res = self._yolo(frame, conf=0.45, classes=[0], verbose=False)[0]
        return [tuple(map(int, b.xyxy[0].tolist())) for b in res.boxes]

    def _detect_sec_objects(self, frame):
        if self._yolo is None: return []
        SEC = {"backpack","laptop","cell phone","book","suitcase","handbag"}
        res = self._yolo(frame, conf=0.4, verbose=False)[0]
        out = []
        for b in res.boxes:
            lbl = res.names[int(b.cls[0])]
            if lbl.lower() in SEC:
                x1,y1,x2,y2 = map(int,b.xyxy[0].tolist())
                out.append({"bbox":[x1,y1,x2,y2],"label":lbl,
                            "confidence":round(float(b.conf[0]),3)})
        return out

    def _motion(self, frame):
        fg = self._bg_sub.apply(frame)
        _, fg = cv2.threshold(fg, 200, 255, cv2.THRESH_BINARY)
        k  = cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(5,5))
        fg = cv2.morphologyEx(fg, cv2.MORPH_OPEN,  k)
        fg = cv2.morphologyEx(fg, cv2.MORPH_CLOSE, k)
        return fg, int(np.count_nonzero(fg))

    def _alert(self, atype, detail, severity="HIGH"):
        if any(a["type"]==atype and a["detail"]==detail for a in self._alerts[-3:]):
            return
        self._alerts.append({
            "id":str(uuid.uuid4())[:8],"type":atype,"detail":detail,
            "time":time.strftime("%H:%M:%S"),"severity":severity,
        })
        if len(self._alerts)>200: self._alerts=self._alerts[-200:]
        self._live_stats["alerts_total"] += 1

    def process(self, frame: np.ndarray, run_recognition=True) -> dict:
        t0 = time.perf_counter()
        self._frame_n += 1
        enhanced = enhance(frame)
        canvas   = enhanced.copy()

        # Motion
        fg_mask, motion_px = self._motion(frame)
        ov = np.zeros_like(canvas)
        ov[fg_mask > 0] = (0,100,255)
        canvas = cv2.addWeighted(canvas, 1.0, ov, 0.2, 0)
        if motion_px > 10000:
            self._alert("MOTION", f"{motion_px:,} foreground pixels")

        # Person detection
        persons = self._detect_persons(enhanced)

        # Tracking
        tracks = self._tracker.update(persons) if persons else []
        track_map = {}
        for (tx1,ty1,tx2,ty2,tid) in tracks:
            best, biou = 0, 0.
            for pi, p in enumerate(persons):
                v = _iou(p,(tx1,ty1,tx2,ty2))
                if v > biou: biou, best = v, pi
            track_map[best] = tid

        recog_results = []
        for pi,(x1,y1,x2,y2) in enumerate(persons):
            tid = track_map.get(pi, pi)
            col = _col(tid)
            is_new = tid not in self._seen_tracks
            if is_new:
                self._seen_tracks.add(tid)
                self._live_stats["persons_detected"] += 1

            identity = {"name":"Unknown","role":"Unknown",
                        "status":"unknown","confidence":0.0}

            if run_recognition:
                # Use cache
                cache_age = self._frame_n - self._id_cache_ttl.get(tid,0)
                if tid in self._id_cache and cache_age < self._cache_frames:
                    identity = self._id_cache[tid]
                else:
                    # Get person crop
                    person_crop = enhanced[max(0,y1):y2, max(0,x1):x2]
                    if person_crop.size > 0:
                        # Try to find face within person crop
                        face_img = self._recogniser._detect_face(person_crop)
                        if face_img is not None and face_img.size > 0:
                            identity = self._recogniser.recognise(face_img)
                        else:
                            # Use top 40% of person (head region)
                            h = y2 - y1
                            head_crop = enhanced[y1:y1+int(h*0.4), max(0,x1):x2]
                            if head_crop.size > 0:
                                identity = self._recogniser.recognise(head_crop)

                    self._id_cache[tid]     = identity
                    self._id_cache_ttl[tid] = self._frame_n

                    # Log on first detection only
                    if is_new:
                        if identity["status"] == "known":
                            self._live_stats["known_count"] += 1
                            self._live_stats["known_log"].append({
                                "name": identity["name"],
                                "role": identity["role"],
                                "time": time.strftime("%H:%M:%S"),
                            })
                            self._alert("KNOWN_PERSON",
                                f"{identity['name']} ({identity['role']}) detected","LOW")
                        else:
                            self._live_stats["unknown_count"] += 1
                            self._live_stats["unknown_log"].append({
                                "track_id": tid,
                                "time":     time.strftime("%H:%M:%S"),
                            })
                            self._alert("UNKNOWN_PERSON",
                                f"Unidentified person – Track #{tid}","HIGH")

            # Draw bounding box
            if identity["status"] == "known":
                s_col = (0,220,100)
                role_str = f" [{identity['role']}]" if identity.get("role") else ""
                s_txt = f"KNOWN: {identity['name']}{role_str}"
            else:
                s_col = (0,60,255)
                s_txt = "UNKNOWN PERSON"

            cv2.rectangle(canvas,(x1,y1),(x2,y2),col,2)
            lbl_txt = f"#{tid} {s_txt}"
            (tw,th),_ = cv2.getTextSize(lbl_txt,cv2.FONT_HERSHEY_SIMPLEX,0.55,2)
            cv2.rectangle(canvas,(x1,y1-th-10),(x1+tw+6,y1),col,-1)
            cv2.putText(canvas,lbl_txt,(x1+3,y1-4),
                        cv2.FONT_HERSHEY_SIMPLEX,0.55,(255,255,255),2)

            recog_results.append({
                "track_id": tid,
                "bbox":     [x1,y1,x2,y2],
                "identity": identity,
            })

        # Security objects
        sec = self._detect_sec_objects(enhanced)
        self._live_stats["objects_detected"] += len(sec)
        for obj in sec:
            ox1,oy1,ox2,oy2 = obj["bbox"]
            cv2.rectangle(canvas,(ox1,oy1),(ox2,oy2),(255,200,0),2)
            cv2.putText(canvas,f"[{obj['label']}]",
                        (ox1,oy1-6),cv2.FONT_HERSHEY_SIMPLEX,0.55,(255,200,0),2)
            self._alert("SECURITY_OBJECT",f"{obj['label']} detected","MED")

        lat = (time.perf_counter()-t0)*1000
        fps = 1000/lat if lat>0 else 0
        for i,(txt,c) in enumerate([
            (f"Frame:{self._frame_n}",(200,200,200)),
            (f"FPS:{fps:.1f}",        (100,255,100)),
            (f"Persons:{len(persons)}",(100,200,255)),
        ]):
            cv2.putText(canvas,txt,(10,24+i*22),cv2.FONT_HERSHEY_SIMPLEX,0.6,c,2)

        _,buf = cv2.imencode(".jpg",canvas,[cv2.IMWRITE_JPEG_QUALITY,82])
        return {
            "frame_b64":        base64.b64encode(buf).decode(),
            "persons":          recog_results,
            "security_objects": sec,
            "motion_pixels":    motion_px,
            "fps":              round(fps,1),
            "latency_ms":       round(lat,1),
            "alerts":           self._alerts[-10:],
            "stats":            self._live_stats.copy(),
        }

    def get_alerts(self):   return list(reversed(self._alerts))
    def get_stats(self):    return self._live_stats.copy()
    def get_enrolled(self): return self._recogniser.get_enrolled()

    def reset_bg(self):
        self._bg_sub = cv2.createBackgroundSubtractorMOG2(
            history=200,varThreshold=50,detectShadows=True)
        self._id_cache.clear(); self._id_cache_ttl.clear()
        self._seen_tracks.clear()

    def reload_faces(self):
        self._recogniser.reload()
        self._id_cache.clear()
        self._id_cache_ttl.clear()

_pipeline: Optional[SentinelPipeline] = None
def get_pipeline() -> SentinelPipeline:
    global _pipeline
    if _pipeline is None: _pipeline = SentinelPipeline()
    return _pipeline
