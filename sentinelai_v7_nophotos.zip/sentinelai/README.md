# SentinelAI – Smart Surveillance & Access Control System
### CSCI435 Computer Vision · University of Wollongong in Dubai · Spring 2026

---

## Quick Start (Windows)

**Just double-click `START.bat`** — it installs everything and opens the app automatically.

Then open **http://localhost:3000** in your browser.

---

## Manual Setup

### Backend (Python / FastAPI)
```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

### Frontend (React)
```bash
cd frontend
npm install
npm start
```

Both must run simultaneously. Open **http://localhost:3000**.

---

## Project Structure

```
sentinelai/
├── START.bat                    ← Double-click to run everything
├── backend/
│   ├── main.py                  ← FastAPI entry point
│   ├── requirements.txt
│   ├── enrolled_faces/          ← Face images for recognition
│   │   ├── Antra.jpg
│   │   └── Sharyu.jpg
│   ├── models/
│   │   └── security_objects.pt  ← Custom fine-tuned YOLOv8 (add here)
│   ├── routers/
│   │   ├── detection.py         ← Image/video frame endpoints
│   │   ├── camera.py            ← Live webcam endpoint
│   │   ├── enrol.py             ← Face enrolment endpoints
│   │   └── alerts.py            ← Alert management endpoints
│   └── services/
│       └── vision_pipeline.py   ← Core CV pipeline (all 6 modules)
└── frontend/
    ├── package.json
    └── src/
        ├── App.js
        ├── components/Sidebar.js
        └── pages/
            ├── Dashboard.js
            ├── LiveCamera.js
            ├── ImageAnalysis.js
            ├── VideoAnalysis.js
            ├── Enrolment.js
            └── AlertCenter.js
```

---

## Vision Modules

| # | Module | Method | Trigger |
|---|--------|--------|---------|
| 1 | Image Enhancement | CLAHE + brightness normalisation | Every frame |
| 2 | Person Detection | YOLOv8n (COCO class 0) | Every frame |
| 3 | Face Recognition | DeepFace FaceNet vs enrolled DB | Image + Live (optional) |
| 4 | Object Tracking | SORT (Kalman filter + Hungarian) | Every frame |
| 5 | Motion Detection | MOG2 background subtraction | Every frame |
| 6 | Security Objects | YOLOv8 fine-tuned (backpack, laptop, phone, card) | Every frame |

---

## Enrolled Personnel

Pre-enrolled:
- **Antra** — `enrolled_faces/Antra.jpg`
- **Sharyu** — `enrolled_faces/Sharyu.jpg`

To add more: Go to the **Enrolment** page in the app and upload a photo.

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/detection/image` | Analyse uploaded image |
| POST | `/api/detection/video-frame` | Analyse single video frame |
| GET  | `/api/camera/frame` | Grab and process webcam frame |
| POST | `/api/camera/reset-bg` | Reset MOG2 background model |
| POST | `/api/enrol/add` | Enrol new person |
| GET  | `/api/enrol/list` | List enrolled persons |
| DELETE | `/api/enrol/{name}` | Remove person |
| GET  | `/api/alerts/` | Get all alerts |
| GET  | `/api/alerts/stats` | Get detection statistics |

---

## References

1. Jocher et al. (2023). Ultralytics YOLOv8. https://github.com/ultralytics/ultralytics
2. Serengil & Ozpinar (2021). DeepFace. https://github.com/serengil/deepface
3. Bradski (2000). The OpenCV Library. Dr. Dobb's Journal.
4. Bewley et al. (2016). Simple Online and Realtime Tracking. IEEE ICIP.
5. Zivkovic (2004). Improved Adaptive GMM for Background Subtraction. ICPR.
6. He et al. (2016). Deep Residual Learning for Image Recognition. CVPR.
7. Schroff et al. (2015). FaceNet. CVPR.
