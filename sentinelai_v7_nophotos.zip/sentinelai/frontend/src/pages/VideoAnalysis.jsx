import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';

export default function VideoAnalysis() {
  const [current,  setCurrent]  = useState(null);
  const [running,  setRunning]  = useState(false);
  const [summary,  setSummary]  = useState(null);
  const stopped = useRef(false);

  // Track unique persons across all frames
  const seenKnown   = useRef(new Map()); // name → {role, time}
  const seenUnknown = useRef(new Set()); // track_ids

  const handleFile = async (file) => {
    if (!file) return;
    setRunning(true); setSummary(null); setCurrent(null);
    stopped.current = false;
    seenKnown.current.clear();
    seenUnknown.current.clear();

    const video  = document.createElement('video');
    video.src    = URL.createObjectURL(file);
    video.muted  = true;
    await new Promise(r => { video.onloadedmetadata = r; });

    const duration = video.duration;
    const canvas   = document.createElement('canvas');
    canvas.width=640; canvas.height=480;
    const ctx = canvas.getContext('2d');
    const step = Math.max(0.5, duration/80);
    let t=0, frames=0;

    while (t < duration && !stopped.current) {
      video.currentTime = t;
      await new Promise(r => { video.onseeked = r; });
      ctx.drawImage(video,0,0,640,480);
      const blob = await new Promise(r => canvas.toBlob(r,'image/jpeg',0.75));
      const fd   = new FormData();
      fd.append('file',blob,'frame.jpg');

      try {
        const res  = await fetch('/api/detection/image',{method:'POST',body:fd});
        const data = await res.json();
        setCurrent(data);
        frames++;

        // Collect unique persons
        data.persons?.forEach(p => {
          if (p.identity.status==='known') {
            if (!seenKnown.current.has(p.identity.name)) {
              seenKnown.current.set(p.identity.name, {
                role: p.identity.role || 'Unknown',
                time: new Date().toLocaleTimeString(),
              });
            }
          } else if (p.identity.status==='unknown') {
            seenUnknown.current.add(p.track_id);
          }
        });
      } catch {}
      t += step;
    }

    setSummary({
      frames,
      known:   Array.from(seenKnown.current.entries()).map(([name,info])=>({name,...info})),
      unknown: seenUnknown.current.size,
    });
    setRunning(false);
    video.src='';
  };

  return (
    <div>
      <div style={{marginBottom:28}}>
        <div style={lbl}>VIDEO ANALYSIS</div>
        <h1 style={{fontSize:'2rem',fontWeight:900,
          background:'linear-gradient(135deg,#c084fc,#f472b6)',
          WebkitBackgroundClip:'text',WebkitTextFillColor:'transparent'}}>
          Video Processing
        </h1>
        <p style={{color:'#475569',fontSize:'0.85rem',marginTop:4}}>
          Each unique person is counted only once — known and unknown shown separately
        </p>
      </div>

      <label style={{display:'block',border:'2px dashed rgba(30,58,95,0.6)',
                     borderRadius:16,padding:'40px',textAlign:'center',
                     cursor:'pointer',background:'rgba(8,15,29,0.6)',marginBottom:20}}>
        <input type="file" accept="video/*" hidden
               onChange={e=>handleFile(e.target.files[0])}/>
        <div style={{fontSize:'2.5rem',marginBottom:10,opacity:0.4}}>📹</div>
        <div style={{color:'#334155',fontSize:'0.9rem'}}>
          Click to upload · <span style={{color:'#c084fc',fontWeight:600}}>MP4 · AVI · MOV</span>
        </div>
      </label>

      {running && (
        <div style={{marginBottom:20}}>
          <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:10}}>
            <div style={{width:8,height:8,borderRadius:'50%',background:'#c084fc',
                         animation:'pulse 1s infinite'}}/>
            <span style={{color:'#c084fc',fontSize:'0.85rem',fontWeight:600}}>
              Processing frames…
            </span>
            <button onClick={()=>{stopped.current=true;setRunning(false);}}
              style={{marginLeft:'auto',background:'rgba(239,68,68,0.1)',
                      border:'1px solid rgba(239,68,68,0.3)',color:'#f87171',
                      padding:'6px 14px',borderRadius:8,cursor:'pointer',fontSize:'0.78rem'}}>
              Stop
            </button>
          </div>
          <div style={{background:'rgba(192,132,252,0.1)',borderRadius:6,height:4,overflow:'hidden'}}>
            <motion.div animate={{width:['0%','100%']}}
              transition={{duration:8,repeat:Infinity,ease:'linear'}}
              style={{height:'100%',background:'linear-gradient(90deg,#c084fc,#818cf8)'}}/>
          </div>
          {current && (
            <img src={`data:image/jpeg;base64,${current.frame_b64}`}
                 alt="frame" style={{width:'100%',borderRadius:12,marginTop:14}}/>
          )}
        </div>
      )}

      {summary && (
        <motion.div initial={{opacity:0,y:12}} animate={{opacity:1,y:0}}>
          {/* Summary stats */}
          <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:12,marginBottom:20}}>
            {[
              ['🎬','Frames Processed', summary.frames,          '#c084fc'],
              ['✅','Unique Known',     summary.known.length,    '#34d399'],
              ['🚫','Unique Unknown',   summary.unknown,         '#f87171'],
            ].map(([icon,k,v,c])=>(
              <div key={k} style={{background:'rgba(8,15,29,0.9)',border:`1px solid ${c}22`,
                                   borderTop:`3px solid ${c}`,borderRadius:14,
                                   padding:'20px',textAlign:'center'}}>
                <div style={{fontSize:'1.5rem',marginBottom:8}}>{icon}</div>
                <div style={{fontSize:'2rem',fontWeight:800,color:c}}>{v}</div>
                <div style={{fontSize:'0.72rem',color:'#475569',marginTop:4}}>{k}</div>
              </div>
            ))}
          </div>

          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16}}>
            {/* Known persons */}
            <div style={card}>
              <div style={{...lbl,color:'#34d399'}}>✅ KNOWN PERSONS DETECTED</div>
              {summary.known.length===0 ? (
                <div style={{color:'#1e3a5f',fontSize:'0.82rem',textAlign:'center',padding:20}}>
                  No known persons found in video
                </div>
              ) : summary.known.map((p,i)=>(
                <div key={i} style={{display:'flex',alignItems:'center',gap:12,
                                     padding:'10px 14px',borderRadius:10,marginBottom:8,
                                     background:'rgba(52,211,153,0.06)',
                                     border:'1px solid rgba(52,211,153,0.15)'}}>
                  <div style={{width:34,height:34,borderRadius:'50%',
                               background:'linear-gradient(135deg,#34d399,#38bdf8)',
                               display:'flex',alignItems:'center',justifyContent:'center',
                               fontWeight:800,fontSize:'0.85rem',color:'#020812',flexShrink:0}}>
                    {p.name[0]}
                  </div>
                  <div style={{flex:1}}>
                    <div style={{fontWeight:700,color:'#34d399',fontSize:'0.88rem'}}>{p.name}</div>
                    <div style={{fontSize:'0.7rem',color:'#475569'}}>{p.role} · First seen {p.time}</div>
                  </div>
                  <div style={{fontSize:'0.68rem',color:'#34d399',background:'rgba(52,211,153,0.1)',
                               padding:'3px 8px',borderRadius:5,flexShrink:0}}>KNOWN</div>
                </div>
              ))}
            </div>

            {/* Unknown persons */}
            <div style={card}>
              <div style={{...lbl,color:'#f87171'}}>🚫 UNKNOWN PERSONS DETECTED</div>
              {summary.unknown===0 ? (
                <div style={{color:'#1e3a5f',fontSize:'0.82rem',textAlign:'center',padding:20}}>
                  No unknown persons found in video
                </div>
              ) : (
                <div style={{textAlign:'center',padding:'30px 20px'}}>
                  <div style={{fontSize:'3rem',fontWeight:900,color:'#f87171',marginBottom:8}}>
                    {summary.unknown}
                  </div>
                  <div style={{color:'#64748b',fontSize:'0.85rem'}}>
                    unidentified {summary.unknown===1?'person':'persons'} detected
                  </div>
                  <div style={{marginTop:16,background:'rgba(239,68,68,0.08)',
                               border:'1px solid rgba(239,68,68,0.2)',
                               borderRadius:10,padding:12,fontSize:'0.78rem',color:'#fca5a5'}}>
                    🚨 Security alert — unrecognised individuals found in footage
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Last processed frame */}
          {current && (
            <div style={{...card,marginTop:16}}>
              <div style={lbl}>LAST PROCESSED FRAME</div>
              <img src={`data:image/jpeg;base64,${current.frame_b64}`}
                   alt="last" style={{width:'100%',borderRadius:10}}/>
            </div>
          )}
        </motion.div>
      )}
      <style>{`@keyframes pulse{0%,100%{opacity:1}50%{opacity:0.3}}`}</style>
    </div>
  );
}

const card = {background:'rgba(8,15,29,0.8)',border:'1px solid rgba(30,58,95,0.4)',borderRadius:16,padding:20};
const lbl  = {fontSize:'0.62rem',letterSpacing:'2px',color:'#334155',fontWeight:700,marginBottom:14};
