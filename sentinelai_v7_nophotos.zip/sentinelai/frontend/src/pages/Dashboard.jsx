import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { AreaChart, Area, XAxis, YAxis, ResponsiveContainer, Tooltip } from 'recharts';

export default function Dashboard() {
  const [stats,   setStats]   = useState({persons_detected:0,known_count:0,unknown_count:0,objects_detected:0,alerts_total:0,known_log:[],unknown_log:[]});
  const [alerts,  setAlerts]  = useState([]);
  const [history, setHistory] = useState([]);

  useEffect(() => {
    const poll = setInterval(async () => {
      try {
        const [sRes, aRes] = await Promise.all([
          fetch('/api/alerts/stats'),
          fetch('/api/alerts/'),
        ]);
        if (sRes.ok) {
          const s = await sRes.json();
          setStats(s);
          setHistory(h => [...h.slice(-30), {
            t: h.length,
            persons: s.persons_detected,
            known:   s.known_count,
            unknown: s.unknown_count,
          }]);
        }
        if (aRes.ok) setAlerts(await aRes.json());
      } catch {}
    }, 2000);
    return () => clearInterval(poll);
  }, []);

  const kpis = [
    {icon:'👥', label:'Total Persons',   value:stats.persons_detected, colour:'#38bdf8'},
    {icon:'✅', label:'Known Persons',    value:stats.known_count,      colour:'#34d399'},
    {icon:'🚫', label:'Unknown Persons',  value:stats.unknown_count,    colour:'#f87171'},
    {icon:'📦', label:'Objects Detected', value:stats.objects_detected, colour:'#f59e0b'},
    {icon:'🚨', label:'Total Alerts',     value:stats.alerts_total,     colour:'#c084fc'},
  ];

  return (
    <div>
      <div style={{marginBottom:28}}>
        <div style={sectionLbl}>LIVE SECURITY DASHBOARD</div>
        <h1 style={{...heading, background:'linear-gradient(135deg,#38bdf8,#818cf8)'}}>
          Security Overview
        </h1>
        <p style={{color:'#475569',fontSize:'0.85rem',marginTop:4}}>
          All data is live — updates every 2 seconds
        </p>
      </div>

      {/* KPIs */}
      <div style={{display:'grid',gridTemplateColumns:'repeat(5,1fr)',gap:12,marginBottom:24}}>
        {kpis.map(({icon,label,value,colour},i)=>(
          <motion.div key={label}
            initial={{opacity:0,y:16}} animate={{opacity:1,y:0}}
            transition={{delay:i*0.08}}
            style={{background:'rgba(8,15,29,0.9)',border:`1px solid ${colour}22`,
                    borderTop:`3px solid ${colour}`,borderRadius:14,padding:'20px 16px'}}>
            <div style={{fontSize:'1.4rem',marginBottom:8}}>{icon}</div>
            <div style={{fontSize:'1.8rem',fontWeight:800,color:colour}}>{value}</div>
            <div style={{fontSize:'0.72rem',color:'#475569',marginTop:4,fontWeight:600}}>{label}</div>
          </motion.div>
        ))}
      </div>

      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16,marginBottom:16}}>
        {/* Activity chart */}
        <div style={card}>
          <div style={sectionLbl}>DETECTION ACTIVITY (LIVE)</div>
          {history.length > 1 ? (
            <ResponsiveContainer width="100%" height={180}>
              <AreaChart data={history}>
                <defs>
                  <linearGradient id="gKnown" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#34d399" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#34d399" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="gUnknown" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f87171" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#f87171" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="t" hide/>
                <YAxis hide/>
                <Tooltip contentStyle={{background:'#0a1628',border:'1px solid #1e3a5f',
                                        borderRadius:8,color:'#e2e8f0'}}/>
                <Area type="monotone" dataKey="known"   stroke="#34d399" fill="url(#gKnown)"   strokeWidth={2}/>
                <Area type="monotone" dataKey="unknown" stroke="#f87171" fill="url(#gUnknown)" strokeWidth={2}/>
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div style={{height:180,display:'flex',alignItems:'center',
                         justifyContent:'center',color:'#1e3a5f',fontSize:'0.85rem'}}>
              Waiting for detections…
            </div>
          )}
        </div>

        {/* Recent alerts */}
        <div style={card}>
          <div style={sectionLbl}>RECENT ALERTS (LIVE)</div>
          {alerts.length===0 ? (
            <div style={{color:'#1e3a5f',fontSize:'0.82rem',textAlign:'center',marginTop:40}}>
              No alerts yet — start a camera or upload an image
            </div>
          ) : (
            <div style={{display:'flex',flexDirection:'column',gap:6,maxHeight:200,overflow:'auto'}}>
              {alerts.slice(0,8).map((a,i)=>(
                <div key={i} style={{
                  display:'flex',alignItems:'center',gap:10,
                  padding:'8px 12px',borderRadius:8,
                  background:a.severity==='HIGH'?'rgba(239,68,68,0.08)':
                             a.severity==='MED' ?'rgba(245,158,11,0.08)':'rgba(52,211,153,0.08)',
                  border:`1px solid ${a.severity==='HIGH'?'rgba(239,68,68,0.2)':
                          a.severity==='MED'?'rgba(245,158,11,0.2)':'rgba(52,211,153,0.2)'}`,
                }}>
                  <div style={{width:6,height:6,borderRadius:'50%',flexShrink:0,
                    background:a.severity==='HIGH'?'#ef4444':
                               a.severity==='MED'?'#f59e0b':'#34d399'}}/>
                  <div style={{flex:1,minWidth:0}}>
                    <div style={{fontSize:'0.75rem',fontWeight:700,color:'#e2e8f0'}}>
                      {a.type.replace(/_/g,' ')}
                    </div>
                    <div style={{fontSize:'0.68rem',color:'#475569',
                                 overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>
                      {a.detail}
                    </div>
                  </div>
                  <div style={{fontSize:'0.62rem',color:'#334155',flexShrink:0}}>{a.time}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Known / Unknown logs */}
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16}}>
        <div style={card}>
          <div style={sectionLbl}>✅ KNOWN PERSONS LOG</div>
          {stats.known_log?.length===0 ? (
            <div style={{color:'#1e3a5f',fontSize:'0.82rem',textAlign:'center',padding:20}}>
              No known persons detected yet
            </div>
          ) : (
            <div style={{display:'flex',flexDirection:'column',gap:6,maxHeight:180,overflow:'auto'}}>
              {[...(stats.known_log||[])].reverse().map((p,i)=>(
                <div key={i} style={{display:'flex',alignItems:'center',gap:10,
                                     padding:'8px 12px',borderRadius:8,
                                     background:'rgba(52,211,153,0.06)',
                                     border:'1px solid rgba(52,211,153,0.15)'}}>
                  <div style={{width:30,height:30,borderRadius:'50%',flexShrink:0,
                               background:'linear-gradient(135deg,#34d399,#38bdf8)',
                               display:'flex',alignItems:'center',justifyContent:'center',
                               fontWeight:800,fontSize:'0.8rem',color:'#020812'}}>
                    {p.name[0]}
                  </div>
                  <div style={{flex:1}}>
                    <div style={{fontSize:'0.82rem',fontWeight:700,color:'#34d399'}}>{p.name}</div>
                    <div style={{fontSize:'0.68rem',color:'#475569'}}>{p.role} · {p.time}</div>
                  </div>
                  <div style={{fontSize:'0.68rem',color:'#34d399',background:'rgba(52,211,153,0.1)',
                               padding:'3px 8px',borderRadius:5}}>KNOWN</div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div style={card}>
          <div style={sectionLbl}>🚫 UNKNOWN PERSONS LOG</div>
          {stats.unknown_log?.length===0 ? (
            <div style={{color:'#1e3a5f',fontSize:'0.82rem',textAlign:'center',padding:20}}>
              No unknown persons detected yet
            </div>
          ) : (
            <div style={{display:'flex',flexDirection:'column',gap:6,maxHeight:180,overflow:'auto'}}>
              {[...(stats.unknown_log||[])].reverse().map((p,i)=>(
                <div key={i} style={{display:'flex',alignItems:'center',gap:10,
                                     padding:'8px 12px',borderRadius:8,
                                     background:'rgba(239,68,68,0.06)',
                                     border:'1px solid rgba(239,68,68,0.15)'}}>
                  <div style={{width:30,height:30,borderRadius:'50%',flexShrink:0,
                               background:'rgba(239,68,68,0.2)',
                               display:'flex',alignItems:'center',justifyContent:'center',
                               fontSize:'1rem'}}>🚫</div>
                  <div style={{flex:1}}>
                    <div style={{fontSize:'0.82rem',fontWeight:700,color:'#f87171'}}>
                      Unknown Person
                    </div>
                    <div style={{fontSize:'0.68rem',color:'#475569'}}>
                      Track #{p.track_id} · {p.time}
                    </div>
                  </div>
                  <div style={{fontSize:'0.68rem',color:'#f87171',background:'rgba(239,68,68,0.1)',
                               padding:'3px 8px',borderRadius:5}}>UNKNOWN</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

const card = {background:'rgba(8,15,29,0.8)',border:'1px solid rgba(30,58,95,0.4)',borderRadius:16,padding:20};
const sectionLbl = {fontSize:'0.62rem',letterSpacing:'2px',color:'#334155',fontWeight:700,marginBottom:12};
const heading = {fontSize:'2rem',fontWeight:900,WebkitBackgroundClip:'text',WebkitTextFillColor:'transparent',marginBottom:4};
