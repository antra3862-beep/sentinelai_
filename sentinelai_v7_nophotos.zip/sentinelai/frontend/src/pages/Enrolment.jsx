import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

const ROLES = ['Student','Teacher','Visitor','Staff'];
const ROLE_COLOURS = {Student:'#38bdf8',Teacher:'#34d399',Visitor:'#f59e0b',Staff:'#c084fc'};

export default function Enrolment() {
  const [enrolled, setEnrolled] = useState([]);
  const [name,     setName]     = useState('');
  const [role,     setRole]     = useState('Student');
  const [file,     setFile]     = useState(null);
  const [preview,  setPreview]  = useState(null);
  const [msg,      setMsg]      = useState('');
  const [loading,  setLoading]  = useState(false);

  const load = async () => {
    try {
      const res  = await fetch('/api/enrol/list');
      const data = await res.json();
      setEnrolled(Array.isArray(data.enrolled) ? data.enrolled : []);
    } catch { setEnrolled([]); }
  };

  useEffect(() => { load(); }, []);

  const handleFile = f => { setFile(f); if(f) setPreview(URL.createObjectURL(f)); };

  const submit = async () => {
    if (!name.trim()) { setMsg('⚠️ Please enter a name.'); return; }
    if (!file)        { setMsg('⚠️ Please select a photo.'); return; }
    setLoading(true); setMsg('');
    const fd = new FormData();
    fd.append('name', name.trim());
    fd.append('role', role);
    fd.append('file', file);
    try {
      const res  = await fetch('/api/enrol/add', {method:'POST', body:fd});
      const data = await res.json();
      setMsg(`✅ ${data.name} enrolled as ${data.role}`);
      setName(''); setFile(null); setPreview(null); setRole('Student');
      load();
    } catch { setMsg('❌ Error enrolling. Is the backend running?'); }
    setLoading(false);
  };

  const remove = async n => {
    await fetch(`/api/enrol/${n}`, {method:'DELETE'});
    load();
  };

  return (
    <div>
      <div style={{marginBottom:28}}>
        <div style={lbl}>USER MANAGEMENT</div>
        <h1 style={{fontSize:'2rem',fontWeight:900,
          background:'linear-gradient(135deg,#f59e0b,#f472b6)',
          WebkitBackgroundClip:'text',WebkitTextFillColor:'transparent'}}>
          Face Enrolment
        </h1>
        <p style={{color:'#475569',fontSize:'0.82rem',marginTop:4}}>
          Enrolled people are recognised by name and role. Anyone else is Unknown.
        </p>
      </div>

      <div style={{display:'grid',gridTemplateColumns:'360px 1fr',gap:20}}>
        {/* Form */}
        <div style={card}>
          <div style={lbl}>ENROL NEW PERSON</div>
          <div style={{marginBottom:14}}>
            <div style={fl}>Full Name</div>
            <input value={name} onChange={e=>setName(e.target.value)}
              placeholder="e.g. John Smith" style={inp}/>
          </div>
          <div style={{marginBottom:14}}>
            <div style={fl}>Role</div>
            <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
              {ROLES.map(r=>(
                <button key={r} onClick={()=>setRole(r)} style={{
                  padding:'7px 14px',borderRadius:8,cursor:'pointer',fontWeight:700,fontSize:'0.76rem',
                  background:role===r?`${ROLE_COLOURS[r]}20`:'rgba(15,30,53,0.5)',
                  border:`1px solid ${role===r?ROLE_COLOURS[r]:'rgba(30,58,95,0.4)'}`,
                  color:role===r?ROLE_COLOURS[r]:'#475569',
                }}>{r}</button>
              ))}
            </div>
          </div>
          <div style={{marginBottom:18}}>
            <div style={fl}>Face Photo</div>
            <label style={{display:'block',border:'2px dashed rgba(30,58,95,0.5)',
                           borderRadius:10,overflow:'hidden',cursor:'pointer',
                           minHeight:70,display:'flex',alignItems:'center',justifyContent:'center'}}>
              <input type="file" accept="image/*" hidden
                     onChange={e=>handleFile(e.target.files[0])}/>
              {preview
                ? <img src={preview} alt="p" style={{width:'100%',maxHeight:170,objectFit:'cover'}}/>
                : <div style={{color:'#334155',fontSize:'0.82rem',padding:20,textAlign:'center'}}>
                    📷 Click to select photo
                  </div>}
            </label>
          </div>
          <button onClick={submit} disabled={loading} style={{
            width:'100%',background:'linear-gradient(135deg,#1d4ed8,#7c3aed)',
            border:'none',borderRadius:10,padding:'11px',color:'white',
            fontWeight:700,fontSize:'0.86rem',cursor:'pointer',opacity:loading?0.7:1}}>
            {loading?'Enrolling…':'Enrol Person'}
          </button>
          {msg && <div style={{marginTop:10,fontSize:'0.8rem',
            color:msg.startsWith('✅')?'#34d399':'#f87171'}}>{msg}</div>}
        </div>

        {/* Enrolled list */}
        <div>
          <div style={{...card,marginBottom:16}}>
            <div style={lbl}>ENROLLED PERSONNEL — {enrolled.length} TOTAL</div>
            {enrolled.length===0 ? (
              <div style={{textAlign:'center',color:'#1e3a5f',padding:'30px 0',fontSize:'0.85rem'}}>
                No one enrolled yet. Add someone using the form.
              </div>
            ) : (
              <div style={{display:'flex',flexDirection:'column',gap:8}}>
                {enrolled.map((p,i)=>(
                  <motion.div key={p.name}
                    initial={{opacity:0,x:-8}} animate={{opacity:1,x:0}}
                    transition={{delay:i*0.04}}
                    style={{display:'flex',alignItems:'center',gap:12,
                            padding:'10px 14px',borderRadius:10,
                            background:`${ROLE_COLOURS[p.role]||'#475569'}08`,
                            border:`1px solid ${ROLE_COLOURS[p.role]||'#475569'}20`}}>
                    <div style={{width:36,height:36,borderRadius:'50%',flexShrink:0,
                                 background:`linear-gradient(135deg,${ROLE_COLOURS[p.role]||'#818cf8'},#818cf8)`,
                                 display:'flex',alignItems:'center',justifyContent:'center',
                                 fontWeight:800,fontSize:'0.85rem',color:'#020812'}}>
                      {p.name[0]?.toUpperCase()}
                    </div>
                    <div style={{flex:1}}>
                      <div style={{fontWeight:700,color:'#e2e8f0',fontSize:'0.86rem'}}>{p.name}</div>
                      <div style={{fontSize:'0.7rem',
                                   color:ROLE_COLOURS[p.role]||'#818cf8'}}>{p.role}</div>
                    </div>
                    <div style={{fontSize:'0.68rem',fontWeight:700,
                                 color:ROLE_COLOURS[p.role]||'#818cf8',
                                 background:`${ROLE_COLOURS[p.role]||'#818cf8'}15`,
                                 padding:'3px 10px',borderRadius:6,marginRight:8}}>
                      {p.role?.toUpperCase()}
                    </div>
                    <button onClick={()=>remove(p.name)} style={{
                      background:'rgba(239,68,68,0.08)',border:'1px solid rgba(239,68,68,0.2)',
                      color:'#f87171',padding:'4px 10px',borderRadius:6,
                      cursor:'pointer',fontSize:'0.72rem',flexShrink:0}}>
                      Remove
                    </button>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
          <div style={{...card,background:'rgba(52,211,153,0.04)',
                       border:'1px solid rgba(52,211,153,0.15)'}}>
            <div style={{fontSize:'0.75rem',color:'#475569',lineHeight:1.7}}>
              <strong style={{color:'#34d399'}}>How recognition works:</strong><br/>
              Only enrolled persons will be identified by name and role.<br/>
              Anyone not in this list will always show as <strong style={{color:'#f87171'}}>Unknown Person</strong>.<br/>
              Add a clear front-facing photo for best results.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const card = {background:'rgba(8,15,29,0.8)',border:'1px solid rgba(30,58,95,0.4)',borderRadius:16,padding:20};
const lbl  = {fontSize:'0.6rem',letterSpacing:'2px',color:'#334155',fontWeight:700,marginBottom:12};
const fl   = {fontSize:'0.74rem',color:'#94a3b8',marginBottom:6,fontWeight:500};
const inp  = {width:'100%',background:'rgba(15,30,53,0.8)',border:'1px solid rgba(30,58,95,0.6)',
              borderRadius:8,padding:'10px 14px',color:'#e2e8f0',fontSize:'0.84rem',
              outline:'none',boxSizing:'border-box'};
