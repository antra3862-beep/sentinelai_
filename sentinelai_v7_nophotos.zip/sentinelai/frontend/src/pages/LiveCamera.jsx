import React, { useState, useRef, useCallback, useEffect } from 'react';
import { motion } from 'framer-motion';

export default function LiveCamera() {
  const [running,  setRunning]  = useState(false);
  const [result,   setResult]   = useState(null);
  const [error,    setError]    = useState('');
  const [useRecog, setUseRecog] = useState(false);
  const [camId,    setCamId]    = useState(0);
  const [status,   setStatus]   = useState('idle'); // idle | connecting | live | error
  const runningRef = useRef(false);
  const timerRef   = useRef(null);

  const fetchFrame = useCallback(async () => {
    if (!runningRef.current) return;
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 15000);
      const res = await fetch(
        `/api/camera/frame?camera_id=${camId}&run_recognition=${useRecog}`,
        { signal: controller.signal }
      );
      clearTimeout(timeout);
      const data = await res.json();
      if (data.error) {
        setError(data.error); setStatus('error');
        runningRef.current = false; setRunning(false); return;
      }
      setResult(data); setError(''); setStatus('live');
    } catch (e) {
      if (e.name === 'AbortError') {
        setError('Request timed out — camera may be slow to respond. Try again.');
      } else {
        setError('Cannot reach backend. Make sure backend black screen is still running.');
      }
      setStatus('error');
      runningRef.current = false; setRunning(false); return;
    }
    if (runningRef.current) timerRef.current = setTimeout(fetchFrame, 150);
  }, [useRecog, camId]);

  const start = useCallback(() => {
    setError(''); setResult(null);
    setStatus('connecting'); setRunning(true);
    runningRef.current = true;
    fetchFrame();
  }, [fetchFrame]);

  const stop = useCallback(() => {
    runningRef.current = false;
    clearTimeout(timerRef.current);
    setRunning(false); setStatus('idle');
  }, []);

  useEffect(() => () => { runningRef.current=false; clearTimeout(timerRef.current); }, []);

  const persons = result?.persons ?? [];
  const known   = persons.filter(p=>p.identity?.status==='known');
  const unknown = persons.filter(p=>p.identity?.status==='unknown');

  return (
    <div>
      <div style={{marginBottom:24}}>
        <div style={lbl}>LIVE MONITORING</div>
        <h1 style={{fontSize:'2rem',fontWeight:900,
          background:'linear-gradient(135deg,#34d399,#38bdf8)',
          WebkitBackgroundClip:'text',WebkitTextFillColor:'transparent'}}>
          Live Camera
        </h1>
        <p style={{color:'#475569',fontSize:'0.82rem',marginTop:4}}>
          Real-time person detection, tracking, and face recognition
        </p>
      </div>

      {/* Controls */}
      <div style={{display:'flex',gap:10,marginBottom:14,flexWrap:'wrap',alignItems:'center'}}>
        {!running ? (
          <motion.button whileTap={{scale:0.96}} onClick={start} style={btn('#34d399')}>
            ▶ Start Camera
          </motion.button>
        ) : (
          <motion.button whileTap={{scale:0.96}} onClick={stop} style={btn('#ef4444')}>
            ⏹ Stop
          </motion.button>
        )}
        <select value={camId} onChange={e=>setCamId(Number(e.target.value))}
          style={{background:'rgba(15,30,53,0.8)',border:'1px solid rgba(30,58,95,0.5)',
                  color:'#94a3b8',padding:'9px 12px',borderRadius:8,fontSize:'0.82rem'}}>
          <option value={0}>Camera 0 (default)</option>
          <option value={1}>Camera 1</option>
          <option value={2}>Camera 2</option>
        </select>
        <label style={{display:'flex',alignItems:'center',gap:6,
                       color:'#94a3b8',fontSize:'0.82rem',cursor:'pointer'}}>
          <input type="checkbox" checked={useRecog}
                 onChange={e=>setUseRecog(e.target.checked)}/>
          Face Recognition
        </label>
        <div style={{marginLeft:'auto',display:'flex',alignItems:'center',gap:6}}>
          <div style={{width:8,height:8,borderRadius:'50%',flexShrink:0,
            background: status==='live'?'#34d399':status==='connecting'?'#f59e0b':
                        status==='error'?'#ef4444':'#334155',
            boxShadow: status==='live'?'0 0 6px #34d399':'none',
            animation: status==='connecting'?'pulse 1s infinite':'none',
          }}/>
          <span style={{fontSize:'0.75rem',fontWeight:600,
            color: status==='live'?'#34d399':status==='connecting'?'#f59e0b':
                   status==='error'?'#ef4444':'#334155'}}>
            {status==='live'?`LIVE · ${result?.fps?.toFixed(1)} FPS`:
             status==='connecting'?'CONNECTING…':
             status==='error'?'ERROR':'OFFLINE'}
          </span>
        </div>
      </div>

      {error && (
        <div style={{background:'rgba(239,68,68,0.08)',border:'1px solid rgba(239,68,68,0.25)',
                     borderRadius:10,padding:12,color:'#f87171',marginBottom:12,fontSize:'0.82rem'}}>
          ⚠️ {error}
          <div style={{marginTop:8,color:'#64748b',fontSize:'0.75rem'}}>
            Tips: Make sure backend is running · Try a different camera index · Check camera is not used by another app
          </div>
        </div>
      )}

      <div style={{display:'grid',gridTemplateColumns:'1fr 280px',gap:14}}>
        {/* Video feed */}
        <div style={{background:'#000',border:'1px solid rgba(30,58,95,0.4)',
                     borderRadius:14,overflow:'hidden',aspectRatio:'4/3',
                     display:'flex',alignItems:'center',justifyContent:'center',
                     position:'relative'}}>
          {result?.frame_b64 ? (
            <img src={`data:image/jpeg;base64,${result.frame_b64}`}
                 alt="feed" style={{width:'100%',height:'100%',objectFit:'cover'}}/>
          ) : (
            <div style={{textAlign:'center',color:'#1e3a5f',padding:20}}>
              <div style={{fontSize:'3rem',marginBottom:12,opacity:0.2}}>🎥</div>
              <div style={{fontSize:'0.85rem',marginBottom:8}}>
                {status==='connecting'?'Opening camera…':'Camera not started'}
              </div>
              {status!=='connecting' && (
                <div style={{fontSize:'0.75rem',color:'#1e3a5f'}}>
                  Press ▶ Start Camera above
                </div>
              )}
            </div>
          )}
          {/* REC badge */}
          {status==='live' && (
            <div style={{position:'absolute',top:12,left:12,
                         display:'flex',alignItems:'center',gap:6,
                         background:'rgba(0,0,0,0.7)',padding:'4px 10px',
                         borderRadius:6}}>
              <div style={{width:8,height:8,borderRadius:'50%',background:'#ef4444',
                           animation:'pulse 1s infinite'}}/>
              <span style={{color:'white',fontSize:'0.72rem',fontWeight:700}}>REC</span>
            </div>
          )}
        </div>

        {/* Side panel */}
        <div style={{display:'flex',flexDirection:'column',gap:10}}>
          <div style={panel}>
            <div style={lbl}>METRICS</div>
            {[
              ['Persons',   persons.length,           '#38bdf8'],
              ['Known',     known.length,             '#34d399'],
              ['Unknown',   unknown.length,           '#f87171'],
              ['Motion px', result?.motion_pixels??0, '#f59e0b'],
              ['FPS',       result?.fps??0,           '#818cf8'],
            ].map(([k,v,c])=>(
              <div key={k} style={{display:'flex',justifyContent:'space-between',
                                   padding:'6px 0',borderBottom:'1px solid #060e1e'}}>
                <span style={{color:'#334155',fontSize:'0.74rem'}}>{k}</span>
                <span style={{color:c,fontWeight:700,fontSize:'0.78rem'}}>{v}</span>
              </div>
            ))}
          </div>

          {known.length>0 && (
            <div style={panel}>
              <div style={{...lbl,color:'#34d399'}}>✅ KNOWN</div>
              {known.map((p,i)=>(
                <div key={i} style={{padding:'8px',borderRadius:8,marginBottom:6,
                  background:'rgba(52,211,153,0.06)',border:'1px solid rgba(52,211,153,0.15)'}}>
                  <div style={{fontWeight:700,fontSize:'0.8rem',color:'#34d399'}}>
                    {p.identity.name}
                  </div>
                  <div style={{fontSize:'0.67rem',color:'#475569'}}>
                    {p.identity.role} · Track #{p.track_id}
                  </div>
                </div>
              ))}
            </div>
          )}

          {unknown.length>0 && (
            <div style={{background:'rgba(239,68,68,0.06)',
                         border:'1px solid rgba(239,68,68,0.2)',
                         borderRadius:12,padding:12}}>
              <div style={{...lbl,color:'#f87171'}}>🚫 UNKNOWN</div>
              {unknown.map((p,i)=>(
                <div key={i} style={{fontSize:'0.76rem',color:'#fca5a5',
                                     marginBottom:4,padding:'4px 0',
                                     borderBottom:'1px solid rgba(239,68,68,0.1)'}}>
                  Unidentified · Track #{p.track_id}
                </div>
              ))}
            </div>
          )}

          {persons.length===0 && status==='live' && (
            <div style={{...panel,textAlign:'center',color:'#1e3a5f',
                         fontSize:'0.78rem',padding:20}}>
              No persons in frame
            </div>
          )}
        </div>
      </div>
      <style>{`@keyframes pulse{0%,100%{opacity:1}50%{opacity:0.3}}`}</style>
    </div>
  );
}

const btn   = c=>({background:`${c}15`,border:`1px solid ${c}40`,color:c,
                    padding:'9px 18px',borderRadius:9,cursor:'pointer',
                    fontWeight:700,fontSize:'0.82rem'});
const panel = {background:'rgba(8,15,29,0.8)',border:'1px solid rgba(30,58,95,0.4)',
               borderRadius:12,padding:14};
const lbl   = {fontSize:'0.6rem',letterSpacing:'2px',color:'#334155',
               fontWeight:700,marginBottom:10};
