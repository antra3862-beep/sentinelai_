import React from 'react';
import { motion } from 'framer-motion';

const NAV = [
  { id:'dashboard', icon:'⬛', label:'Dashboard' },
  { id:'live',      icon:'🔴', label:'Live Camera' },
  { id:'image',     icon:'🖼️', label:'Image Analysis' },
  { id:'video',     icon:'📹', label:'Video Analysis' },
  { id:'enrolment', icon:'👤', label:'Enrolment' },
  { id:'alerts',    icon:'🚨', label:'Alert Center' },
];

export default function Sidebar({ active, setPage, alertCount }) {
  return (
    <div style={{
      width: 240,
      background: 'linear-gradient(180deg,#060e1e 0%,#040a17 100%)',
      borderRight: '1px solid rgba(30,58,95,0.4)',
      display: 'flex', flexDirection: 'column',
      padding: '24px 0', position: 'sticky', top: 0, height: '100vh',
    }}>
      {/* Brand */}
      <div style={{padding:'0 24px 32px'}}>
        <div style={{fontSize:'1.5rem', marginBottom:6}}>🛡️</div>
        <div style={{
          fontSize:'1.1rem', fontWeight:800,
          background:'linear-gradient(135deg,#38bdf8,#818cf8)',
          WebkitBackgroundClip:'text', WebkitTextFillColor:'transparent',
        }}>SentinelAI</div>
        <div style={{fontSize:'0.7rem',color:'#334155',marginTop:2}}>
          Smart Surveillance System
        </div>
      </div>

      {/* Status */}
      <div style={{
        margin:'0 16px 24px',
        background:'rgba(52,211,153,0.08)',
        border:'1px solid rgba(52,211,153,0.2)',
        borderRadius:10, padding:'10px 14px',
        display:'flex', alignItems:'center', gap:8,
      }}>
        <div style={{
          width:8,height:8,borderRadius:'50%',
          background:'#34d399',
          boxShadow:'0 0 8px #34d399',
          animation:'pulse 2s infinite',
        }}/>
        <span style={{fontSize:'0.75rem',color:'#34d399',fontWeight:600}}>
          System Online
        </span>
      </div>

      {/* Nav */}
      <nav style={{flex:1, padding:'0 12px'}}>
        {NAV.map(({id,icon,label}) => {
          const isActive = active === id;
          return (
            <motion.button
              key={id}
              onClick={() => setPage(id)}
              whileHover={{x:4}}
              whileTap={{scale:0.97}}
              style={{
                display:'flex', alignItems:'center', gap:12,
                width:'100%', padding:'11px 14px',
                borderRadius:10, border:'none', cursor:'pointer',
                marginBottom:4, textAlign:'left',
                background: isActive
                  ? 'linear-gradient(135deg,rgba(56,189,248,0.15),rgba(129,140,248,0.1))'
                  : 'transparent',
                borderLeft: isActive ? '2px solid #38bdf8' : '2px solid transparent',
                color: isActive ? '#e2e8f0' : '#475569',
                fontSize:'0.85rem', fontWeight: isActive ? 600 : 400,
                transition:'all 0.2s',
              }}
            >
              <span style={{fontSize:'1rem'}}>{icon}</span>
              <span>{label}</span>
              {id === 'alerts' && alertCount > 0 && (
                <span style={{
                  marginLeft:'auto',
                  background:'#ef4444', color:'white',
                  fontSize:'0.65rem', fontWeight:700,
                  padding:'2px 7px', borderRadius:10,
                }}>
                  {alertCount}
                </span>
              )}
            </motion.button>
          );
        })}
      </nav>

      {/* Footer */}
      <div style={{padding:'16px 24px',borderTop:'1px solid rgba(30,58,95,0.3)'}}>
        <div style={{fontSize:'0.65rem',color:'#1e3a5f',lineHeight:1.6}}>
          CSCI435 · UOWD<br/>Spring 2026
        </div>
      </div>

      <style>{`
        @keyframes pulse {
          0%,100%{opacity:1} 50%{opacity:0.4}
        }
      `}</style>
    </div>
  );
}
