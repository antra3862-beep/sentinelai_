import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Sidebar from './components/Sidebar.jsx';
import Dashboard from './pages/Dashboard.jsx';
import LiveCamera from './pages/LiveCamera.jsx';
import ImageAnalysis from './pages/ImageAnalysis.jsx';
import VideoAnalysis from './pages/VideoAnalysis.jsx';
import Enrolment from './pages/Enrolment.jsx';
import AlertCenter from './pages/AlertCenter.jsx';

const pages = {
  dashboard:   Dashboard,
  live:        LiveCamera,
  image:       ImageAnalysis,
  video:       VideoAnalysis,
  enrolment:   Enrolment,
  alerts:      AlertCenter,
};

export default function App() {
  const [page, setPage] = useState('dashboard');
  const [alerts, setAlerts] = useState([]);
  const [stats, setStats]   = useState({persons:0,known:0,unknown:0,objects:0,alerts:0});

  useEffect(() => {
    const poll = setInterval(async () => {
      try {
        const [aRes, sRes] = await Promise.all([
          fetch('/api/alerts/'),
          fetch('/api/alerts/stats'),
        ]);
        if (aRes.ok) setAlerts(await aRes.json());
        if (sRes.ok) setStats(await sRes.json());
      } catch {}
    }, 3000);
    return () => clearInterval(poll);
  }, []);

  const Page = pages[page] || Dashboard;

  return (
    <div style={{display:'flex',minHeight:'100vh',background:'#020812'}}>
      <Sidebar active={page} setPage={setPage} alertCount={alerts.length} />
      <main style={{flex:1,overflow:'auto',padding:'32px 36px'}}>
        <AnimatePresence mode="wait">
          <motion.div
            key={page}
            initial={{opacity:0, y:16}}
            animate={{opacity:1, y:0}}
            exit={{opacity:0,  y:-16}}
            transition={{duration:0.3, ease:'easeOut'}}
          >
            <Page alerts={alerts} stats={stats} />
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}
